import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import cron from "node-cron";
import nodemailer from "nodemailer";
import admin from "firebase-admin";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin
const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf-8"));

admin.initializeApp({
  projectId: firebaseConfig.projectId,
});

const db = admin.firestore();

async function notifyAppsScript(type: string, data: any): Promise<boolean> {
  const appScriptUrl = (process.env.APPSCRIPT_URL || "https://script.google.com/macros/s/AKfycbyzRa4HUUFR5v4pKvfv_b--2-n-hCrDMQp-WG92ioNtElrb3YVPMZJMiKaZ3myNBDpC/exec").trim();
  const recipients = ["recGRANFIESTA@HMHOTELS.COM", "rec1GRANFIESTA@HMHOTELS.COM"];
  
  if (!appScriptUrl) {
    console.error("[Notification] Apps Script URL is empty. Skipping notification.");
    return false;
  }

  console.log(`[Notification] Sending ${type} to: ${appScriptUrl}`);

  try {
    const response = await fetch(appScriptUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      },
      body: JSON.stringify({
        type: type,
        data: { ...data, recipients },
        secret: process.env.APPSCRIPT_SECRET || null
      }),
      redirect: "follow"
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => "No error body");
      console.error(`[Notification] Apps Script Error (${response.status}): ${errorText}`);
      return false;
    }

    console.log(`[Notification] ${type} sent successfully.`);
    return true;
  } catch (error) {
    console.error(`[Notification] Fetch Error:`, error);
    return false;
  }
}

async function checkUpcomingEvents() {
  console.log("Checking for upcoming events (1 and 2 days ahead)...");
  
  try {
    const today = new Date();
    
    // Check for 1 day ahead
    const oneDayFromNow = new Date(today);
    oneDayFromNow.setDate(today.getDate() + 1);
    const date1Str = oneDayFromNow.toISOString().split('T')[0];
    
    // Check for 2 days ahead
    const twoDaysFromNow = new Date(today);
    twoDaysFromNow.setDate(today.getDate() + 2);
    const date2Str = twoDaysFromNow.toISOString().split('T')[0];

    const collectionsToCheck = [
      { name: "news_events", dateField: "startDate" },
      { name: "event_pdfs", dateField: "eventDate" }
    ];

    for (const coll of collectionsToCheck) {
      // Query for 1 day ahead
      const events1Snapshot = await db.collection(coll.name)
        .where(coll.dateField, "==", date1Str)
        .get();
      
      for (const doc of events1Snapshot.docs) {
        await notifyAppsScript("event_reminder_1d", { ...doc.data(), collection: coll.name });
      }

      // Query for 2 days ahead
      const events2Snapshot = await db.collection(coll.name)
        .where(coll.dateField, "==", date2Str)
        .get();

      for (const doc of events2Snapshot.docs) {
        await notifyAppsScript("event_reminder_2d", { ...doc.data(), collection: coll.name });
      }
    }
  } catch (error) {
    console.error("Error checking upcoming events:", error);
  }
}

async function sendNotificationEmail(events: any[]) {
  const recipients = ["recGRANFIESTA@HMHOTELS.COM", "rec1GRANFIESTA@HMHOTELS.COM"];
  
  // SMTP Configuration from environment variables
  const smtpConfig = {
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587"),
    secure: process.env.SMTP_PORT === "465",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  };

  if (!smtpConfig.host || !smtpConfig.auth.user || !smtpConfig.auth.pass) {
    console.warn("SMTP is not fully configured. Skipping email sending.");
    console.log("Notification would have been sent to:", recipients.join(", "));
    console.log("Events:", JSON.stringify(events, null, 2));
    return;
  }

  const transporter = nodemailer.createTransport(smtpConfig);

  const eventList = events.map(e => `- ${e.title}: ${e.description.replace(/<[^>]*>?/gm, '')}`).join("\n");
  
  const mailOptions = {
    from: process.env.SMTP_FROM || "noreply@hmhotels.net",
    to: recipients.join(", "),
    subject: `Recordatorio: Eventos en 2 días`,
    text: `Hola,\n\nEste es un recordatorio de que los siguientes eventos comenzarán en 2 días:\n\n${eventList}\n\nSaludos,\nSistema de Recepción`,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Notification email sent to ${recipients.join(", ")}`);
  } catch (error) {
    console.error("Error sending email:", error);
  }
}

// Schedule the task to run every day at 08:00 AM
cron.schedule("0 8 * * *", () => {
  checkUpcomingEvents();
});

// Also run it once on startup for testing/immediate check
// checkUpcomingEvents();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Manual trigger for testing
  app.post("/api/notifications/check", async (req, res) => {
    await checkUpcomingEvents();
    res.json({ message: "Check triggered" });
  });

  app.post("/api/notifications/novedad", express.json(), async (req, res) => {
    const event = req.body;
    console.log(`[API] Received notification request for: ${event.title || 'Untitled'}`);
    const success = await notifyAppsScript("new_novedad", event);
    if (success) {
      res.json({ message: "Notification sent" });
    } else {
      res.status(500).json({ error: "Failed to send notification to Apps Script. Check server logs." });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
